# ============================================
# MODELO EDP DINÂMICO COMPLETO COM ASSIMILAÇÃO
# ============================================

library(tidyverse)
library(zoo)

# -------------------------------------------------
# 1. FUNÇÕES AUXILIARES DO MODELO EDP
# -------------------------------------------------

# 1.1 PASSO DE ADVECÇÃO-DIFUSÃO
passo_edp_dinamico <- function(estado, u, v, config, dt) {
  # estado$C: matriz nx × ny com concentrações
  # u, v: componentes do vento (m/s)
  # config: parâmetros do modelo
  # dt: passo de tempo (s)
  
  nx <- config$nx
  ny <- config$ny
  dx <- config$dx
  dy <- config$dy
  K <- config$K_h
  lambda <- config$lambda
  
  C_old <- estado$C
  C_new <- matrix(0, nrow = nx, ncol = ny)
  
  # Percorrer interior do domínio (evitando bordas)
  for(i in 2:(nx-1)) {
    for(j in 2:(ny-1)) {
      
      # --- ADVECÇÃO (esquema upwind para estabilidade) ---
      if(u > 0) {
        adv_x <- u * (C_old[i, j] - C_old[i-1, j]) / dx
      } else {
        adv_x <- u * (C_old[i+1, j] - C_old[i, j]) / dx
      }
      
      if(v > 0) {
        adv_y <- v * (C_old[i, j] - C_old[i, j-1]) / dy
      } else {
        adv_y <- v * (C_old[i, j+1] - C_old[i, j]) / dy
      }
      
      adveccao <- -(adv_x + adv_y)
      
      # --- DIFUSÃO (Laplaciano com diferenças centradas) ---
      laplaciano <- (C_old[i+1, j] - 2*C_old[i, j] + C_old[i-1, j]) / (dx^2) +
        (C_old[i, j+1] - 2*C_old[i, j] + C_old[i, j-1]) / (dy^2)
      
      difusao <- K * laplaciano
      
      # --- DEPOSIÇÃO/REMOÇÃO ---
      remocao <- -lambda * C_old[i, j]
      
      # --- ATUALIZAÇÃO EULER EXPLÍCITO ---
      C_new[i, j] <- C_old[i, j] + dt * (adveccao + difusao + remocao)
    }
  }
  
  # Condições de contorno (Neumann: gradiente zero)
  C_new[1,] <- C_new[2,]  # Borda oeste
  C_new[nx,] <- C_new[nx-1,]  # Borda leste
  C_new[,1] <- C_new[,2]  # Borda sul
  C_new[,ny] <- C_new[,ny-1]  # Borda norte
  
  # Evitar valores negativos
  C_new <- pmax(C_new, 5)  # Mínimo de 5 μg/m³ (background)
  
  return(list(
    C = C_new,
    tempo = estado$tempo + dt
  ))
}

# 1.2 ASSIMILAÇÃO DE DADOS (NUDGING)
assimilacao_nudging <- function(estado, C_observado, config, peso = 0.3) {
  # peso: 0 = ignora observação, 1 = força valor exato
  
  if(is.na(C_observado)) {
    return(estado)  # Sem dado para assimilar
  }
  
  C <- estado$C
  nx <- config$nx
  ny <- config$ny
  
  # Índice do centro (onde está a estação)
  i_center <- floor(nx/2)
  j_center <- floor(ny/2)
  
  # Aplicar nudging apenas numa pequena região ao redor da estação
  raio_nudging <- 3  # células
  
  for(i in max(1, i_center-raio_nudging):min(nx, i_center+raio_nudging)) {
    for(j in max(1, j_center-raio_nudging):min(ny, j_center+raio_nudging)) {
      
      # Distância da estação (normalizada)
      dist <- sqrt((i - i_center)^2 + (j - j_center)^2) / raio_nudging
      
      # Peso que decai com distância (Gaussiana)
      peso_local <- peso * exp(-dist^2 / 2)
      
      # Ajuste
      C[i, j] <- C[i, j] + peso_local * (C_observado - C[i, j])
    }
  }
  
  # Garantir que o centro tenha exatamente o valor observado
  C[i_center, j_center] <- C_observado
  
  return(list(
    C = C,
    tempo = estado$tempo
  ))
}

# 1.3 ESTIMATIVA DE FONTE
atualizar_fonte <- function(estado, delta_C, dir_vento, config, intensidade = 0.1) {
  # Adiciona fonte a montante quando detecta pico
  
  nx <- config$nx
  ny <- config$ny
  dx <- config$dx
  dy <- config$dy
  
  # Converter direção para radianos
  dir_rad <- dir_vento * pi / 180
  
  # Posição da estação (centro)
  i_center <- floor(nx/2)
  j_center <- floor(ny/2)
  
  # Calcular posição a montante (oposta ao vento)
  dist_fonte <- 2000 / dx  # 2 km a montante em células
  
  i_fonte <- round(i_center - dist_fonte * sin(dir_rad))
  j_fonte <- round(j_center - dist_fonte * cos(dir_rad))
  
  # Garantir que está dentro do domínio
  i_fonte <- max(2, min(nx-1, i_fonte))
  j_fonte <- max(2, min(ny-1, j_fonte))
  
  # Adicionar emissão na posição da fonte
  estado$C[i_fonte, j_fonte] <- estado$C[i_fonte, j_fonte] + 
    delta_C * intensidade
  
  cat(sprintf("  Fonte adicionada em (%d, %d): +%.1f μg/m³\n", 
              i_fonte, j_fonte, delta_C * intensidade))
  
  return(estado)
}

# -------------------------------------------------
# 2. MODELO PRINCIPAL COMPLETO
# -------------------------------------------------
modelo_dinamico_pm25 <- function(
    dados_2min,        # DataFrame com: timestamp, pm25, u, v
    buffer_km = 5,
    resolucao_m = 200,
    salvar_cada = 5    # Salvar resultados a cada N passos
) {
  
  cat("=========================================\n")
  cat("MODELO EDP DINÂMICO COM ASSIMILAÇÃO\n")
  cat("=========================================\n")
  
  # 1. PRÉ-PROCESSAMENTO DOS DADOS
  cat("1. Pré-processando dados...\n")
  
  if(!"pm25" %in% names(dados_2min)) {
    stop("DataFrame deve ter coluna 'pm25'")
  }
  
  if(!"u" %in% names(dados_2min) | !"v" %in% names(dados_2min)) {
    # Se não tiver u,v, calcular de dir_vento e vel_vento
    if("dir_vento" %in% names(dados_2min) & "vel_vento" %in% names(dados_2min)) {
      dados_2min <- dados_2min %>%
        mutate(
          dir_rad = dir_vento * pi / 180,
          u = vel_vento * sin(dir_rad),
          v = vel_vento * cos(dir_rad)
        )
    } else {
      stop("Precisa de u,v ou dir_vento+vel_vento")
    }
  }
  
  # Converter timestamp se necessário
  if(!inherits(dados_2min$timestamp, "POSIXct")) {
    dados_2min$timestamp <- as.POSIXct(dados_2min$timestamp)
  }
  
  # Ordenar por tempo
  dados_2min <- dados_2min[order(dados_2min$timestamp), ]
  
  # Suavizar dados (média móvel de 10 min para reduzir ruído)
  cat("   Aplicando suavização (média móvel 10 min)...\n")
  
  dados_suav <- dados_2min %>%
    mutate(
      pm25_smooth = zoo::rollapply(pm25, width = 5, 
                                   FUN = mean, 
                                   fill = NA, 
                                   align = "center", 
                                   na.rm = TRUE),
      u_smooth = zoo::rollapply(u, width = 5, 
                                FUN = mean, 
                                fill = NA, 
                                align = "center", 
                                na.rm = TRUE),
      v_smooth = zoo::rollapply(v, width = 5, 
                                FUN = mean, 
                                fill = NA, 
                                align = "center", 
                                na.rm = TRUE)
    )
  
  # Remover NAs no início/fim
  dados_suav <- dados_suav[complete.cases(dados_suav[, c("pm25_smooth", "u_smooth", "v_smooth")]), ]
  
  cat(sprintf("   Dados válidos após suavização: %d registros\n", nrow(dados_suav)))
  
  # 2. CONFIGURAR MODELO EDP DINÂMICO
  cat("2. Configurando modelo...\n")
  
  buffer_m <- buffer_km * 1000
  config <- list(
    nx = floor(2 * buffer_m / resolucao_m),
    ny = floor(2 * buffer_m / resolucao_m),
    dx = resolucao_m,
    dy = resolucao_m,
    K_h = 20,      # Coef. difusão horizontal (m²/s)
    lambda = 1e-6, # Taxa de remoção (s⁻¹)
    buffer_km = buffer_km
  )
  
  # Índice do centro (estação)
  i_center <- floor(config$nx/2)
  j_center <- floor(config$ny/2)
  
  cat(sprintf("   Grade: %d x %d células (%.1f km x %.1f km)\n", 
              config$nx, config$ny, 
              config$nx * config$dx / 1000, 
              config$ny * config$dy / 1000))
  cat(sprintf("   Resolução: %.0f m\n", resolucao_m))
  cat(sprintf("   Centro (estação): célula (%d, %d)\n", i_center, j_center))
  
  # 3. INICIALIZAR ESTADO
  cat("3. Inicializando estado...\n")
  
  # Background inicial (10 μg/m³ em todo domínio)
  estado <- list(
    C = matrix(10, nrow = config$nx, ncol = config$ny),
    tempo = dados_suav$timestamp[1],
    passo = 0
  )
  
  # 4. LOOP TEMPORAL PRINCIPAL
  cat("4. Iniciando simulação temporal...\n\n")
  
  resultados <- list()
  n_passos <- nrow(dados_suav)
  
  # Barra de progresso simples
  cat("Progresso: [")
  
  for(i in 2:n_passos) {
    
    # Tempo atual e intervalo
    t_atual <- dados_suav$timestamp[i]
    dt_actual <- as.numeric(difftime(t_atual, dados_suav$timestamp[i-1], units = "secs"))
    
    if(dt_actual <= 0) {
      warning(sprintf("dt negativo ou zero no passo %d. Pulando.", i))
      next
    }
    
    # 4.1. PASSO DE ADVECÇÃO-DIFUSÃO (EDP)
    estado <- passo_edp_dinamico(
      estado = estado,
      u = dados_suav$u_smooth[i],
      v = dados_suav$v_smooth[i],
      config = config,
      dt = dt_actual
    )
    
    # 4.2. ASSIMILAÇÃO DE DADOS (NUDGING)
    estado <- assimilacao_nudging(
      estado = estado,
      C_observado = dados_suav$pm25_smooth[i],
      config = config,
      peso = 0.4  # Peso de assimilação
    )
    
    estado$tempo <- t_atual
    estado$passo <- estado$passo + 1
    
    # 4.3. DETECÇÃO DE PICOS (opcional)
    if(i > 10) {
      media_anterior <- mean(dados_suav$pm25_smooth[(i-10):(i-1)], na.rm = TRUE)
      if(!is.na(media_anterior) & !is.na(dados_suav$pm25_smooth[i])) {
        if(dados_suav$pm25_smooth[i] > media_anterior * 1.3) {
          cat(sprintf("\n  ! Pico detectado em %s: %.1f → %.1f μg/m³\n",
                      format(t_atual, "%H:%M"),
                      media_anterior,
                      dados_suav$pm25_smooth[i]))
          
          # Atualizar fonte se tiver direção do vento
          if("dir_vento" %in% names(dados_suav)) {
            estado <- atualizar_fonte(
              estado = estado,
              delta_C = dados_suav$pm25_smooth[i] - media_anterior,
              dir_vento = dados_suav$dir_vento[i],
              config = config,
              intensidade = 0.2
            )
          }
        }
      }
    }
    
    # 4.4. ARMAZENAR RESULTADO (a cada N passos)
    if(i %% salvar_cada == 0) {
      resultados[[length(resultados) + 1]] <- list(
        timestamp = t_atual,
        C = estado$C,
        pm25_obs = dados_suav$pm25_smooth[i],
        pm25_mod = estado$C[i_center, j_center],
        u = dados_suav$u_smooth[i],
        v = dados_suav$v_smooth[i],
        passo = estado$passo
      )
    }
    
    # Progresso
    if(i %% floor(n_passos/50) == 0) cat("=")
  }
  
  cat("]\n\n")
  
  # 5. PROCESSAR RESULTADOS
  cat("5. Processando resultados...\n")
  
  # Converter resultados para formatos mais úteis
  timestamps <- sapply(resultados, function(x) x$timestamp)
  pm25_obs <- sapply(resultados, function(x) x$pm25_obs)
  pm25_mod <- sapply(resultados, function(x) x$pm25_mod)
  
  # Estatísticas de desempenho
  idx_valido <- !is.na(pm25_obs) & !is.na(pm25_mod)
  if(sum(idx_valido) > 0) {
    rmse <- sqrt(mean((pm25_obs[idx_valido] - pm25_mod[idx_valido])^2))
    bias <- mean(pm25_mod[idx_valido] - pm25_obs[idx_valido])
    r2 <- 1 - sum((pm25_obs[idx_valido] - pm25_mod[idx_valido])^2) / 
      sum((pm25_obs[idx_valido] - mean(pm25_obs[idx_valido]))^2)
    
    cat(sprintf("   RMSE: %.2f μg/m³\n", rmse))
    cat(sprintf("   Bias: %.2f μg/m³\n", bias))
    cat(sprintf("   R²: %.3f\n", r2))
  }
  
  # 6. RETORNAR RESULTADOS
  cat("6. Simulação concluída!\n")
  
  return(list(
    resultados = resultados,
    config = config,
    dados_suav = dados_suav,
    estatisticas = list(
      n_passos = length(resultados),
      timestamps = timestamps,
      pm25_obs = pm25_obs,
      pm25_mod = pm25_mod
    ),
    estado_final = estado
  ))
}

# -------------------------------------------------
# 3. FUNÇÕES DE VISUALIZAÇÃO
# -------------------------------------------------

# 3.1 PLOT DA SÉRIE TEMPORAL COMPARATIVA
plot_serie_temporal <- function(resultado) {
  
  df_plot <- data.frame(
    timestamp = resultado$estatisticas$timestamps,
    Observado = resultado$estatisticas$pm25_obs,
    Modelado = resultado$estatisticas$pm25_mod
  )
  
  p <- ggplot(df_plot, aes(x = timestamp)) +
    geom_line(aes(y = Observado, color = "Observado"), size = 0.8, alpha = 0.7) +
    geom_line(aes(y = Modelado, color = "Modelado"), size = 0.8, alpha = 0.7) +
    scale_color_manual(values = c("Observado" = "red", "Modelado" = "blue")) +
    labs(
      title = "Comparação: PM2.5 Observado vs Modelado",
      subtitle = "Modelo EDP Dinâmico com Assimilação",
      x = "Tempo",
      y = "PM2.5 (μg/m³)",
      color = ""
    ) +
    theme_minimal() +
    theme(legend.position = "top")
  
  return(p)
}

# 3.2 PLOT DO MAPA EM UM INSTANTE ESPECÍFICO
plot_mapa_instantaneo <- function(resultado, passo = NULL) {
  
  if(is.null(passo)) {
    passo <- length(resultado$resultados)  # Último passo
  }
  
  res <- resultado$resultados[[passo]]
  config <- resultado$config
  
  # Converter matriz para data.frame
  nx <- config$nx
  ny <- config$ny
  dx <- config$dx
  dy <- config$dy
  
  grid <- expand.grid(
    x = seq(-config$buffer_km, config$buffer_km, length.out = nx),
    y = seq(-config$buffer_km, config$buffer_km, length.out = ny)
  )
  
  grid$pm25 <- as.vector(res$C)
  
  # Buffer circular
  grid$dist <- sqrt(grid$x^2 + grid$y^2)
  grid <- grid[grid$dist <= config$buffer_km, ]
  
  p <- ggplot(grid, aes(x = x, y = y)) +
    geom_tile(aes(fill = pm25)) +
    geom_point(aes(x = 0, y = 0), 
               color = "yellow", size = 3, shape = 17) +
    scale_fill_viridis_c(
      name = "PM2.5\n(μg/m³)",
      option = "plasma",
      limits = c(5, max(grid$pm25))
    ) +
    coord_fixed() +
    labs(
      title = sprintf("Distribuição de PM2.5 - %s", 
                      format(res$timestamp, "%H:%M")),
      subtitle = sprintf("Observado: %.1f μg/m³ | Modelado: %.1f μg/m³",
                         res$pm25_obs, res$pm25_mod),
      x = "Distância Leste-Oeste (km)",
      y = "Distância Norte-Sul (km)"
    ) +
    theme_minimal()
  
  return(p)
}

# 3.3 GERAR ANIMAÇÃO (GIF)
gerar_animacao <- function(resultado, fps = 5, duracao = 10) {
  
  library(gganimate)
  library(gifski)
  
  # Preparar dados para animação
  anim_data <- list()
  
  for(i in seq_along(resultado$resultados)) {
    res <- resultado$resultados[[i]]
    config <- resultado$config
    
    nx <- config$nx
    ny <- config$ny
    
    grid <- expand.grid(
      x = seq(-config$buffer_km, config$buffer_km, length.out = nx),
      y = seq(-config$buffer_km, config$buffer_km, length.out = ny)
    )
    
    grid$pm25 <- as.vector(res$C)
    grid$frame <- i
    grid$time <- format(res$timestamp, "%H:%M")
    
    # Buffer circular
    grid$dist <- sqrt(grid$x^2 + grid$y^2)
    grid <- grid[grid$dist <= config$buffer_km, ]
    
    anim_data[[i]] <- grid
  }
  
  anim_data <- do.call(rbind, anim_data)
  
  # Criar animação
  p <- ggplot(anim_data, aes(x = x, y = y)) +
    geom_tile(aes(fill = pm25)) +
    geom_point(aes(x = 0, y = 0), color = "yellow", size = 2) +
    scale_fill_viridis_c(option = "plasma", limits = c(5, max(anim_data$pm25))) +
    coord_fixed() +
    transition_states(frame, transition_length = 1, state_length = 1) +
    labs(
      title = "Dispersão de PM2.5: {anim_data$time[which(anim_data$frame == closest_state)]}",
      subtitle = "Modelo EDP Dinâmico com Assimilação",
      fill = "PM2.5 (μg/m³)"
    ) +
    theme_minimal()
  
  # Renderizar GIF
  n_frames <- length(unique(anim_data$frame))
  animate(p, nframes = n_frames, fps = fps, 
          width = 600, height = 600, 
          renderer = gifski_renderer("edp_animacao.gif"))
  
  cat("Animação salva como 'edp_animacao.gif'\n")
}

# -------------------------------------------------
# 4. TESTE COM DADOS FICTÍCIOS
# -------------------------------------------------
testar_modelo_completo <- function() {
  
  cat("=== TESTE DO MODELO EDP COMPLETO ===\n\n")
  
  # Gerar dados de teste (1 dia, a cada 2 minutos)
  set.seed(123)
  
  # Criar timestamps
  inicio <- as.POSIXct("2024-06-10 00:00:00")
  timestamps <- seq(inicio, by = "2 min", length.out = 720)  # 24 horas
  
  # Gerar dados simulados
  dados_teste <- data.frame(
    timestamp = timestamps,
    hora = hour(timestamps),
    pm25 = 15 + 10 * sin(2 * pi * (hour(timestamps) + 6) / 24) +  # Ciclo diurno
      rnorm(length(timestamps), 0, 3),  # Ruído
    dir_vento = (270 + 30 * sin(2 * pi * hour(timestamps) / 24)) %% 360,
    vel_vento = 3 + sin(2 * pi * hour(timestamps) / 24) + 
      rnorm(length(timestamps), 0, 0.5)
  )
  
  # Adicionar evento de poluição às 14h
  idx_evento <- which(hour(timestamps) == 14)
  dados_teste$pm25[idx_evento] <- dados_teste$pm25[idx_evento] + 30
  
  # Limitar valores
  dados_teste$pm25 <- pmax(5, dados_teste$pm25)
  dados_teste$vel_vento <- pmax(0.5, dados_teste$vel_vento)
  
  cat(sprintf("Dados de teste: %d registros (%.1f horas)\n", 
              nrow(dados_teste), nrow(dados_teste)*2/60))
  
  # Executar modelo
  resultado <- modelo_dinamico_pm25(
    dados_2min = dados_teste,
    buffer_km = 3,  # Buffer menor para teste rápido
    resolucao_m = 300,
    salvar_cada = 10  # Salvar a cada 20 minutos
  )
  
  # Visualizar resultados
  p1 <- plot_serie_temporal(resultado)
  p2 <- plot_mapa_instantaneo(resultado, passo = 1)
  p3 <- plot_mapa_instantaneo(resultado, passo = length(resultado$resultados))
  
  library(patchwork)
  plot_final <- (p1) / (p2 | p3)
  
  print(plot_final)
  
  # Salvar resultados
  saveRDS(resultado, "resultado_teste_edp.rds")
  cat("\nResultado salvo como 'resultado_teste_edp.rds'\n")
  
  return(resultado)
}

# -------------------------------------------------
# 5. FUNÇÃO PARA USAR COM SEUS DADOS
# -------------------------------------------------
executar_com_seus_dados <- function(caminho_arquivo) {
  
  cat("=== EXECUTANDO MODELO COM SEUS DADOS ===\n\n")
  
  # 1. Carregar seus dados
  dados <- read.csv(caminho_arquivo, stringsAsFactors = FALSE)
  
  # Verificar colunas necessárias
  colunas_necessarias <- c("timestamp", "pm25")
  colunas_opcionais <- c("u", "v", "dir_vento", "vel_vento")
  
  if(!all(colunas_necessarias %in% names(dados))) {
    stop(sprintf("Arquivo precisa ter colunas: %s", 
                 paste(colunas_necessarias, collapse = ", ")))
  }
  
  # Converter timestamp
  dados$timestamp <- as.POSIXct(dados$timestamp)
  
  # 2. Executar modelo
  resultado <- modelo_dinamico_pm25(
    dados_2min = dados,
    buffer_km = 5,
    resolucao_m = 200,
    salvar_cada = 5  # Salvar a cada 10 minutos
  )
  
  # 3. Gerar visualizações
  p1 <- plot_serie_temporal(resultado)
  ggsave("serie_temporal.png", p1, width = 10, height = 6)
  
  # Mapa do último passo
  p2 <- plot_mapa_instantaneo(resultado)
  ggsave("mapa_final.png", p2, width = 8, height = 8)
  
  # 4. Exportar resultados
  # Grade do último passo
  ultimo_passo <- resultado$resultados[[length(resultado$resultados)]]
  grade_final <- data.frame(
    x = rep(seq(-5, 5, length.out = resultado$config$nx), 
            resultado$config$ny),
    y = rep(seq(-5, 5, length.out = resultado$config$ny), 
            each = resultado$config$nx),
    pm25 = as.vector(ultimo_passo$C)
  )
  
  write.csv(grade_final, "grade_final_pm25.csv", row.names = FALSE)
  
  # Estatísticas temporais
  stats_temporais <- data.frame(
    timestamp = resultado$estatisticas$timestamps,
    pm25_obs = resultado$estatisticas$pm25_obs,
    pm25_mod = resultado$estatisticas$pm25_mod
  )
  
  write.csv(stats_temporais, "comparacao_temporal.csv", row.names = FALSE)
  
  cat("\n=== RESULTADOS EXPORTADOS ===\n")
  cat("• serie_temporal.png - Gráfico comparativo\n")
  cat("• mapa_final.png - Mapa da distribuição\n")
  cat("• grade_final_pm25.csv - Dados da grade\n")
  cat("• comparacao_temporal.csv - Dados temporais\n")
  
  return(resultado)
}

# -------------------------------------------------
# 6. EXECUÇÃO
# -------------------------------------------------

# Opção 1: Teste com dados fictícios
 resultado_teste <- testar_modelo_completo()

# Opção 2: Usar com seus dados
# resultado_real <- executar_com_seus_dados("dados_edp_teste.csv")

# Para gerar animação (pode ser pesado)
 gerar_animacao(resultado_teste, fps = 2, duracao = 15)

cat("\n" + strrep("=", 60) + "\n")
cat("MODELO EDP DINÂMICO PRONTO PARA USO!\n")
cat(strrep("=", 60) + "\n\n")

cat("Para testar:\n")
cat("1. resultado_teste <- testar_modelo_completo()\n")
cat("2. resultado_real <- executar_com_seus_dados('dados_edp_teste.csv')\n\n")

cat("O modelo inclui:\n")
cat("• Advecção pelo vento\n")
cat("• Difusão turbulenta\n")
cat("• Remoção por deposição\n")
cat("• Assimilação de dados (nudging)\n")
cat("• Detecção automática de picos\n")
cat("• Visualizações e exportação\n")