# ============================================
# MODELO EDP 2D PARA DISPERSÃO DE PM2.5
# ============================================

library(tidyverse)
library(deSolve)  # Para resolver EDOs/EDPs
library(geometry)  # Para calcular gradientes
library(fields)    # Para interpolação

# -------------------------------------------------
# 1. EQUAÇÃO PRINCIPAL: Advecção-Difusão 2D
# -------------------------------------------------
# ∂C/∂t = -u·∇C + ∇·(K∇C) - λC + S
#
# Onde:
# C(x,y,t): concentração de PM2.5
# u(x,y): campo de vento (2D)
# K: coeficiente de difusão turbulenta
# λ: taxa de deposição/remoção
# S(x,y,t): fontes
# -------------------------------------------------

# -------------------------------------------------
# 2. FUNÇÃO PARA RESOLVER A EDP NUMERICAMENTE
# -------------------------------------------------
resolver_edp_pm25 <- function(
    C_estacao,          # Concentração medida na estação (μg/m³)
    dir_vento,          # Direção do vento (graus)
    vel_vento,          # Velocidade do vento (m/s)
    buffer_km = 5,      # Raio do buffer
    resolucao_m = 200,  # Resolução espacial
    tempo_simulacao = 3600,  # Tempo de simulação (s) - 1 hora
    K_horizontal = 10,  # Coef. difusão horizontal (m²/s)
    taxa_deposicao = 0.0001,  # λ (s⁻¹) ~ meia-vida de 2 horas
    altura_camada = 500  # H (m) para conversão 2D
) {
  
  cat("Resolvendo EDP de Advecção-Difusão 2D...\n")
  
  # 2.1 CONFIGURAÇÃO DO DOMÍNIO
  buffer_m <- buffer_km * 1000
  nx <- ny <- floor(2 * buffer_m / resolucao_m) + 1
  dx <- dy <- resolucao_m
  
  # Coordenadas
  x <- seq(-buffer_m, buffer_m, length.out = nx)
  y <- seq(-buffer_m, buffer_m, length.out = ny)
  
  # Grade 2D
  grid <- expand.grid(x = x, y = y)
  grid$dist <- sqrt(grid$x^2 + grid$y^2)
  
  # Manter apenas buffer circular
  grid <- grid[grid$dist <= buffer_m, ]
  
  # 2.2 CAMPO DE VENTO (constante por simplicidade)
  dir_rad <- dir_vento * pi / 180
  u_x <- vel_vento * sin(dir_rad)  # Componente leste-oeste
  u_y <- vel_vento * cos(dir_rad)  # Componente norte-sul
  
  # 2.3 CONDIÇÕES INICIAIS E DE CONTORNO
  
  # Condição inicial: concentração zero em todo domínio
  C0 <- matrix(0, nrow = nx, ncol = ny)
  
  # Posição da estação no grid
  idx_estacao <- which.min(abs(x)) + (which.min(abs(y)) - 1) * nx
  
  # 2.4 FUNÇÃO DA EDP (lado direito da equação)
  edp_2d <- function(t, C, params) {
    # Reformatar para matriz 2D
    C_mat <- matrix(C, nrow = nx, ncol = ny)
    
    # Inicializar derivada temporal
    dCdt <- matrix(0, nrow = nx, ncol = ny)
    
    # Extrair parâmetros
    u_x <- params$u_x
    u_y <- params$u_y
    K <- params$K
    lambda <- params$lambda
    dx <- params$dx
    dy <- params$dy
    
    # PERCORRER INTERIOR DO DOMÍNIO (evitando bordas)
    for(i in 2:(nx-1)) {
      for(j in 2:(ny-1)) {
        # --- ADVECÇÃO (u·∇C) ---
        # Derivadas espaciais (diferenças centradas)
        dCdx <- (C_mat[i+1, j] - C_mat[i-1, j]) / (2 * dx)
        dCdy <- (C_mat[i, j+1] - C_mat[i, j-1]) / (2 * dy)
        
        adveccao <- -(u_x * dCdx + u_y * dCdy)
        
        # --- DIFUSÃO (∇·(K∇C)) ---
        # Laplaciano (diferenças centradas de 2ª ordem)
        laplaciano <- (C_mat[i+1, j] - 2*C_mat[i, j] + C_mat[i-1, j]) / (dx^2) +
          (C_mat[i, j+1] - 2*C_mat[i, j] + C_mat[i, j-1]) / (dy^2)
        
        difusao <- K * laplaciano
        
        # --- DEPOSIÇÃO/REMOÇÃO (-λC) ---
        remocao <- -lambda * C_mat[i, j]
        
        # --- FONTE NA ESTAÇÃO ---
        fonte <- 0
        if(i == which.min(abs(x)) && j == which.min(abs(y))) {
          # Injetar PM2.5 na estação como fonte pontual
          # Baseado na concentração medida (convertida para taxa de emissão)
          Q <- C_estacao * 0.1  # Taxa de emissão simplificada (μg/s)
          fonte <- Q / (dx * dy * altura_camada)  # Converter para μg/(m³·s)
        }
        
        # --- EQUAÇÃO COMPLETA ---
        dCdt[i, j] <- adveccao + difusao + remocao + fonte
      }
    }
    
    # Condições de contorno (Neumann: fluxo zero nas bordas)
    dCdt[1,] <- dCdt[nx,] <- dCdt[,1] <- dCdt[,ny] <- 0
    
    return(list(as.vector(dCdt)))
  }
  
  # 2.5 PARÂMETROS
  params <- list(
    u_x = u_x,
    u_y = u_y,
    K = K_horizontal,
    lambda = taxa_deposicao,
    dx = dx,
    dy = dy,
    nx = nx,
    ny = ny
  )
  
  # 2.6 RESOLVER EDP NO TEMPO
  cat("Integrando no tempo...\n")
  
  # Tempos de integração
  times <- seq(0, tempo_simulacao, by = 60)  # Passos de 1 minuto
  
  # Resolver usando método de Euler explícito (simplificado)
  C_sim <- euler_explicito_edp(C0, times, params, edp_2d)
  
  # 2.7 PROCESSAR RESULTADOS
  resultado <- processar_resultados_edp(C_sim, grid, x, y, 
                                        C_estacao, dir_vento, vel_vento,
                                        buffer_km)
  
  return(resultado)
}

# -------------------------------------------------
# 3. MÉTODO NUMÉRICO SIMPLIFICADO (Euler Explícito)
# -------------------------------------------------
euler_explicito_edp <- function(C0, times, params, edp_func) {
  nx <- params$nx
  ny <- params$ny
  
  # Inicializar array 3D para armazenar resultados
  # [tempo, x, y]
  C_all <- array(0, dim = c(length(times), nx, ny))
  C_all[1,,] <- C0
  
  # Integração temporal (Euler explícito)
  for(t_idx in 2:length(times)) {
    dt <- times[t_idx] - times[t_idx-1]
    
    # Calcular derivada
    dCdt <- edp_func(times[t_idx-1], as.vector(C_all[t_idx-1,,]), params)
    
    # Atualizar
    C_new <- C_all[t_idx-1,,] + matrix(dCdt[[1]], nrow = nx, ncol = ny) * dt
    
    # Aplicar condições de contorno
    C_new[1,] <- C_new[nx,] <- C_new[,1] <- C_new[,ny] <- 0
    
    # Evitar valores negativos
    C_new <- pmax(C_new, 0)
    
    C_all[t_idx,,] <- C_new
  }
  
  return(C_all)
}

# -------------------------------------------------
# 4. PROCESSAR E VISUALIZAR RESULTADOS
# -------------------------------------------------
processar_resultados_edp <- function(C_sim, grid, x, y, 
                                     C_estacao, dir_vento, vel_vento,
                                     buffer_km) {
  
  # Pegar estado final (último tempo)
  nx <- length(x)
  ny <- length(y)
  C_final <- matrix(0, nrow = nx, ncol = ny)
  
  # Último passo de tempo
  C_final <- C_sim[dim(C_sim)[1],,]
  
  # Converter para data.frame para plotting
  grid_result <- expand.grid(x = x, y = y)
  grid_result$pm25 <- as.vector(C_final)
  
  # Adicionar distância do centro
  grid_result$dist <- sqrt(grid_result$x^2 + grid_result$y^2) / 1000
  
  # Filtrar buffer circular
  grid_result <- grid_result[grid_result$dist <= buffer_km, ]
  
  # Normalizar para que a estação tenha o valor medido
  idx_centro <- which.min(grid_result$dist)
  if(length(idx_centro) > 0) {
    fator_normalizacao <- C_estacao / max(1e-6, grid_result$pm25[idx_centro])
    grid_result$pm25 <- grid_result$pm25 * fator_normalizacao
  }
  
  # Garantir mínimo de 5 μg/m³ (background)
  grid_result$pm25 <- pmax(grid_result$pm25, 5)
  
  # 4.1 GERAR MAPA
  p <- ggplot(grid_result, aes(x = x/1000, y = y/1000)) +
    geom_tile(aes(fill = pm25)) +
    
    # Estação no centro
    geom_point(aes(x = 0, y = 0), 
               color = "yellow", fill = "black",
               size = 5, shape = 21, stroke = 2) +
    
    # Seta do vento
    geom_segment(
      aes(x = 0, y = 0, 
          xend = vel_vento * sin(dir_vento * pi/180) * 0.5,
          yend = vel_vento * cos(dir_vento * pi/180) * 0.5),
      arrow = arrow(length = unit(0.3, "cm")),
      color = "blue", size = 1.2
    ) +
    
    # Buffer circular
    annotate("path",
             x = buffer_km * cos(seq(0, 2*pi, length.out = 100)),
             y = buffer_km * sin(seq(0, 2*pi, length.out = 100)),
             color = "black", size = 0.8, linetype = "dashed") +
    
    # Escala de cores
    scale_fill_viridis_c(
      name = "PM2.5\n(μg/m³)",
      option = "plasma",
      limits = c(5, max(grid_result$pm25))
    ) +
    
    # Formatação
    coord_fixed(ratio = 1) +
    labs(
      title = "Modelo EDP 2D: Advecção-Difusão de PM2.5",
      subtitle = sprintf("Estação: %.1f μg/m³ | Vento: %.0f° @ %.1f m/s", 
                         C_estacao, dir_vento, vel_vento),
      x = "Distância Leste-Oeste (km)",
      y = "Distância Norte-Sul (km)",
      caption = "∂C/∂t = -u·∇C + K∇²C - λC + S"
    ) +
    theme_minimal()
  
  # 4.2 ESTATÍSTICAS
  stats <- list(
    media = mean(grid_result$pm25),
    mediana = median(grid_result$pm25),
    maximo = max(grid_result$pm25),
    minimo = min(grid_result$pm25),
    desvio_padrao = sd(grid_result$pm25),
    area_acima_25 = sum(grid_result$pm25 > 25) * 
      (mean(diff(unique(grid_result$x)))/1000)^2
  )
  
  cat("\n=== ESTATÍSTICAS DO MODELO EDP ===\n")
  cat(sprintf("Concentração média: %.1f μg/m³\n", stats$media))
  cat(sprintf("Concentração máxima: %.1f μg/m³\n", stats$maximo))
  cat(sprintf("Área > 25 μg/m³: %.1f km²\n", stats$area_acima_25))
  
  # 4.3 RETORNAR RESULTADOS
  return(list(
    grade = grid_result,
    mapa = p,
    estatisticas = stats,
    parametros = list(
      C_estacao = C_estacao,
      dir_vento = dir_vento,
      vel_vento = vel_vento,
      buffer_km = buffer_km,
      K_horizontal = 10,
      taxa_deposicao = 0.0001
    )
  ))
}

# -------------------------------------------------
# 5. MÉTODO ALTERNATIVO: SOLUÇÃO ANALÍTICA SIMPLIFICADA
# -------------------------------------------------
# Para casos com vento constante e fonte pontual,
# existe solução analítica da EDP!
# -------------------------------------------------

solucao_analitica_edp <- function(
    C_estacao, dir_vento, vel_vento, buffer_km = 5,
    K = 10, lambda = 0.0001, resolucao_m = 200
) {
  
  cat("Calculando solução analítica da EDP...\n")
  
  # Esta é a solução fundamental da equação de advecção-difusão
  # para uma fonte instantânea no ponto (0,0) no tempo t=0
  
  # Criar grade
  buffer_m <- buffer_km * 1000
  x_seq <- seq(-buffer_m, buffer_m, by = resolucao_m)
  y_seq <- seq(-buffer_m, buffer_m, by = resolucao_m)
  
  grid <- expand.grid(x = x_seq, y = y_seq)
  grid$dist <- sqrt(grid$x^2 + grid$y^2) / 1000
  grid <- grid[grid$dist <= buffer_km, ]
  
  # Converter direção do vento
  dir_rad <- dir_vento * pi / 180
  
  # Rotacionar coordenadas para alinhar com vento
  grid$x_rot <- grid$x * cos(dir_rad) + grid$y * sin(dir_rad)
  grid$y_rot <- -grid$x * sin(dir_rad) + grid$y * cos(dir_rad)
  
  # Parâmetros da solução
  t <- 3600  # Tempo de 1 hora (s)
  Q <- C_estacao * 1000  # Força da fonte (μg)
  
  # Solução analítica (fonte instantânea em meio infinito)
  # C(x,y,t) = [Q/(4πKt)] * exp(-[(x-ut)² + y²]/(4Kt) - λt)
  
  grid$pm25 <- (Q / (4 * pi * K * t)) *
    exp(-((grid$x_rot - vel_vento * t)^2 + grid$y_rot^2) / (4 * K * t) -
          lambda * t)
  
  # Adicionar background
  grid$pm25 <- grid$pm25 + 5
  
  # Normalizar para que centro tenha valor medido
  idx_centro <- which.min(grid$dist)
  if(length(idx_centro) > 0) {
    fator <- C_estacao / grid$pm25[idx_centro]
    grid$pm25 <- grid$pm25 * fator
  }
  
  # Gerar mapa
  p <- ggplot(grid, aes(x = x/1000, y = y/1000)) +
    geom_tile(aes(fill = pm25)) +
    scale_fill_viridis_c(name = "PM2.5\n(μg/m³)", option = "plasma") +
    coord_fixed() +
    labs(title = "Solução Analítica da EDP",
         subtitle = "Fonte pontual instantânea com advecção-difusão") +
    theme_minimal()
  
  print(p)
  
  return(list(grade = grid, mapa = p))
}

# -------------------------------------------------
# 6. COMPARAÇÃO: EDP vs KRIGAGEM
# -------------------------------------------------
comparar_edp_krigagem <- function(C_estacao, dir_vento, vel_vento) {
  
  cat("=== COMPARAÇÃO ENTRE MÉTODOS ===\n\n")
  
  # Método 1: EDP (numérico)
  cat("1. Executando modelo EDP...\n")
  resultado_edp <- resolver_edp_pm25(
    C_estacao = C_estacao,
    dir_vento = dir_vento,
    vel_vento = vel_vento,
    buffer_km = 5,
    resolucao_m = 300,
    tempo_simulacao = 1800  # 30 minutos
  )
  
  # Método 2: Krigagem (do código anterior)
  cat("\n2. Executando Krigagem...\n")
  
  # Função simplificada da Krigagem (do código anterior)
  resultado_krig <- estimar_buffer_krigagem_simplificado(
    valor_estacao = C_estacao,
    dir_vento = dir_vento,
    vel_vento = vel_vento,
    buffer_km = 5,
    resolucao_m = 300
  )
  
  # Comparação estatística
  cat("\n=== COMPARAÇÃO ESTATÍSTICA ===\n")
  cat(sprintf("%-20s %10s %10s\n", "Estatística", "EDP", "Krigagem"))
  cat(sprintf("%-20s %10.1f %10.1f\n", "Média (μg/m³)",
              resultado_edp$estatisticas$media,
              resultado_krig$estatisticas$media))
  cat(sprintf("%-20s %10.1f %10.1f\n", "Máximo (μg/m³)",
              resultado_edp$estatisticas$maximo,
              resultado_krig$estatisticas$maximo))
  cat(sprintf("%-20s %10.1f %10.1f\n", "Desvio Padrão",
              resultado_edp$estatisticas$desvio_padrao,
              resultado_krig$estatisticas$desvio_padrao))
  
  # Plotar comparação lado a lado
  library(patchwork)
  p_comparacao <- resultado_edp$mapa + resultado_krig$mapa +
    plot_annotation(title = sprintf(
      "Comparação: EDP vs Krigagem | PM2.5: %.1f μg/m³", C_estacao))
  
  print(p_comparacao)
  
  return(list(
    edp = resultado_edp,
    krigagem = resultado_krig,
    comparacao = p_comparacao
  ))
}

# -------------------------------------------------
# 7. FUNÇÃO AUXILIAR: Krigagem Simplificada
# -------------------------------------------------
estimar_buffer_krigagem_simplificado <- function(
    valor_estacao, dir_vento, vel_vento, buffer_km, resolucao_m) {
  
  # Versão simplificada da função anterior
  library(gstat)
  
  # Criar pontos de amostragem
  set.seed(123)
  n_pontos <- 12
  
  # Estação no centro
  pontos <- data.frame(
    x = 0, y = 0, pm25 = valor_estacao
  )
  
  # Pontos auxiliares (simulando gradiente de vento)
  for(i in 1:n_pontos) {
    ang <- runif(1, 0, 2*pi)
    dist <- runif(1, 1, buffer_km) * 1000
    
    # Ajustar valor baseado na direção relativa ao vento
    dir_rel <- abs((ang - dir_vento*pi/180 + pi) %% (2*pi) - pi)
    fator <- 1.0 - 0.3 * (dir_rel / pi)
    
    valor <- valor_estacao * fator * exp(-dist/(vel_vento*1000))
    valor <- max(5, min(valor_estacao * 1.5, valor))
    
    pontos <- rbind(pontos, data.frame(
      x = dist * cos(ang),
      y = dist * sin(ang),
      pm25 = valor
    ))
  }
  
  # Criar grade
  buffer_m <- buffer_km * 1000
  grid <- expand.grid(
    x = seq(-buffer_m, buffer_m, by = resolucao_m),
    y = seq(-buffer_m, buffer_m, by = resolucao_m)
  )
  grid$dist <- sqrt(grid$x^2 + grid$y^2) / 1000
  grid <- grid[grid$dist <= buffer_km, ]
  
  # Krigagem ordinária
  coordinates(pontos) <- ~ x + y
  coordinates(grid) <- ~ x + y
  
  variograma <- variogram(pm25 ~ 1, pontos)
  modelo <- vgm(psill = 0.5 * var(pontos$pm25), 
                model = "Exp", 
                range = buffer_m * 0.4,
                nugget = 0.1 * var(pontos$pm25))
  
  modelo_ajustado <- fit.variogram(variograma, modelo)
  krig <- krige(pm25 ~ 1, pontos, grid, modelo_ajustado)
  
  resultado <- as.data.frame(krig)
  resultado$pm25 <- pmax(resultado$var1.pred, 5)
  
  # Estatísticas
  stats <- list(
    media = mean(resultado$pm25, na.rm = TRUE),
    maximo = max(resultado$pm25, na.rm = TRUE),
    desvio_padrao = sd(resultado$pm25, na.rm = TRUE)
  )
  
  return(list(
    grade = resultado,
    estatisticas = stats,
    mapa = NULL  # Será criado na função de comparação
  ))
}

# -------------------------------------------------
# 8. EXECUÇÃO DE EXEMPLOS
# -------------------------------------------------

# Exemplo 1: Modelo EDP completo
cat("=== EXEMPLO 1: MODELO EDP COMPLETO ===\n")
exemplo_edp <- resolver_edp_pm25(
  C_estacao = 65,
  dir_vento = 315,  # Vento NW
  vel_vento = 3.5,
  buffer_km = 5,
  resolucao_m = 250,
  tempo_simulacao = 3600  # 30 minutos
)

# Exemplo 2: Solução analítica
cat("\n=== EXEMPLO 2: SOLUÇÃO ANALÍTICA ===\n")
exemplo_analitico <- solucao_analitica_edp(
  C_estacao = 65,
  dir_vento = 315,
  vel_vento = 3.5
)

# Exemplo 3: Comparação direta
cat("\n=== EXEMPLO 3: COMPARAÇÃO EDP vs KRIGAGEM ===\n")
comparacao <- comparar_edp_krigagem(
  C_estacao = 45,
  dir_vento = 270,  # Vento Oeste
  vel_vento = 2.5
)

# -------------------------------------------------
# 9. ANÁLISE DE SENSIBILIDADE DOS PARÂMETROS
# -------------------------------------------------
analisar_sensibilidade_edp <- function() {
  
  cat("=== ANÁLISE DE SENSIBILIDADE ===\n")
  
  # Testar diferentes coeficientes de difusão
  K_values <- c(1, 5, 10, 20, 50)  # m²/s
  
  resultados <- list()
  
  for(i in seq_along(K_values)) {
    cat(sprintf("\nTeste %d: K = %.0f m²/s\n", i, K_values[i]))
    
    res <- resolver_edp_pm25(
      C_estacao = 50,
      dir_vento = 0,  # Vento Norte
      vel_vento = 3.0,
      buffer_km = 5,
      K_horizontal = K_values[i],
      tempo_simulacao = 3600
    )
    
    resultados[[i]] <- list(
      K = K_values[i],
      media = res$estatisticas$media,
      desvio = res$estatisticas$desvio_padrao,
      area_25 = res$estatisticas$area_acima_25
    )
  }
  
  # Plotar sensibilidade
  sens_df <- do.call(rbind, lapply(resultados, as.data.frame))
  
  p1 <- ggplot(sens_df, aes(x = K, y = media)) +
    geom_line() + geom_point() +
    labs(title = "Sensibilidade: Coeficiente de Difusão",
         x = "K (m²/s)", y = "PM2.5 médio (μg/m³)") +
    theme_minimal()
  
  p2 <- ggplot(sens_df, aes(x = K, y = desvio)) +
    geom_line() + geom_point() +
    labs(x = "K (m²/s)", y = "Desvio padrão (μg/m³)") +
    theme_minimal()
  
  library(patchwork)
  print(p1 / p2)
  
  return(sens_df)
}

# Executar análise de sensibilidade
 sensibilidade <- analisar_sensibilidade_edp()

# -------------------------------------------------
# 10. FUNÇÃO PARA EXPORTAR RESULTADOS
# -------------------------------------------------
exportar_resultados_edp <- function(resultado, nome_arquivo = "edp_pm25") {
  
  # Salvar grade
  write.csv(
    resultado$grade,
    file = paste0(nome_arquivo, "_grade.csv"),
    row.names = FALSE
  )
  
  # Salvar parâmetros
  write.csv(
    as.data.frame(resultado$parametros),
    file = paste0(nome_arquivo, "_parametros.csv"),
    row.names = FALSE
  )
  
  # Salvar estatísticas
  write.csv(
    as.data.frame(resultado$estatisticas),
    file = paste0(nome_arquivo, "_estatisticas.csv"),
    row.names = FALSE
  )
  
  # Salvar mapa
  ggsave(
    filename = paste0(nome_arquivo, "_mapa.png"),
    plot = resultado$mapa,
    width = 8, height = 7, dpi = 300
  )
  
  cat(sprintf("Resultados exportados em %s_*.{csv,png}\n", nome_arquivo))
}

# -------------------------------------------------
# USO PRÁTICO
# -------------------------------------------------

# Para usar com SEUS dados:
meus_resultados_edp <- resolver_edp_pm25(
  C_estacao = 40,      # SUA medição
  dir_vento = 1,     # SUA direção do vento
  vel_vento = 10,     # SUA velocidade
  buffer_km = 10,
  resolucao_m = 500
)

# Visualizar
print(meus_resultados_edp$mapa)

  # Exportar
exportar_resultados_edp(meus_resultados_edp, "meu_modelo_edp")