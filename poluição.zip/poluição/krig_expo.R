# ============================================
# MODELO: ESTIMAR PM2.5 NO BUFFER A PARTIR DA ESTAÇÃO
# ============================================

library(tidyverse)
library(sf)
library(gstat)
library(ggplot2)
library(viridis)

# -------------------------------------------------
# 1. FUNÇÃO PRINCIPAL: Estimativa por Krigagem
# -------------------------------------------------
# Usa a medição da estação + vento para criar um campo gradiente
estimar_buffer_krigagem <- function(
    valor_estacao,           # PM2.5 medido na estação (μg/m³)
    dir_vento,              # Direção de onde VEM o vento (graus)
    vel_vento,              # Velocidade do vento (m/s)
    buffer_km = 5,          # Raio do buffer
    n_pontos_aux = 8,       # Pontos auxiliares para criar gradiente
    resolucao_m = 200       # Resolução da grade
) {
  
  cat("Estimando PM2.5 em buffer de", buffer_km, "km...\n")
  
  # 1.1 Criar pontos de dados (estação + pontos auxiliares)
  criar_pontos_amostrais <- function(valor_central, dir_vento, vel_vento, n_aux, buffer_km) {
    # Estação no centro
    pontos <- data.frame(
      id = "estacao",
      x = 0,
      y = 0,
      pm25 = valor_central
    )
    
    # Criar pontos auxiliares a montante (menor concentração)
    dir_rad <- dir_vento * pi / 180
    
    for(i in 1:n_aux) {
      # Pontos a montante: concentração decai
      distancia <- buffer_km * 0.8 * runif(1, 0.5, 1)
      angulo <- dir_rad + runif(1, -0.3, 0.3)  # Pequena variação angular
      
      x_aux <- -distancia * 1000 * sin(angulo)  # Montante é oposto ao vento
      y_aux <- -distancia * 1000 * cos(angulo)
      
      # Decaimento exponencial com distância e vento
      decaimento <- exp(-distancia / (vel_vento + 1))
      valor_aux <- valor_central * (0.2 + 0.8 * decaimento) * runif(1, 0.8, 1.2)
      
      pontos <- rbind(pontos, data.frame(
        id = paste0("aux_", i),
        x = x_aux,
        y = y_aux,
        pm25 = max(5, valor_aux)  # Mínimo 5 μg/m³
      ))
    }
    
    # Adicionar pontos de background nas bordas
    for(j in 1:4) {
      ang <- runif(1, 0, 2*pi)
      dist <- buffer_km * 0.9
      
      pontos <- rbind(pontos, data.frame(
        id = paste0("bg_", j),
        x = dist * 1000 * sin(ang),
        y = dist * 1000 * cos(ang),
        pm25 = 10 + runif(1, -3, 3)  # Background ~10 μg/m³
      ))
    }
    
    return(pontos)
  }
  
  pontos <- criar_pontos_amostrais(valor_estacao, dir_vento, vel_vento, n_pontos_aux, buffer_km)
  
  # 1.2 Criar grade para interpolação
  criar_grade_buffer <- function(raio_km, res_m) {
    raio_m <- raio_km * 1000
    grid <- expand.grid(
      x = seq(-raio_m, raio_m, by = res_m),
      y = seq(-raio_m, raio_m, by = res_m)
    )
    grid$dist <- sqrt(grid$x^2 + grid$y^2) / 1000
    grid <- grid[grid$dist <= raio_km, ]
    return(grid)
  }
  
  grid <- criar_grade_buffer(buffer_km, resolucao_m)
  
  # 1.3 Interpolação por Krigagem Ordinária
  interpolar_krigagem <- function(pontos, grid) {
    # Converter para objetos espaciais
    coordinates(pontos) <- ~ x + y
    coordinates(grid) <- ~ x + y
    
    # Ajustar variograma
    variograma <- variogram(pm25 ~ 1, pontos)
    
    # Ajustar modelo ao variograma (exponencial)
    modelo_vgm <- vgm(
      psill = 0.5 * var(pontos$pm25),  # Parcial sill
      model = "Exp",                   # Modelo exponencial
      range = buffer_km * 1000 * 0.4,  # Alcance: 40% do buffer
      nugget = 0.1 * var(pontos$pm25)  # Efeito pepita
    )
    
    modelo_ajustado <- fit.variogram(variograma, modelo_vgm)
    
    # Krigagem
    krigagem_resultado <- krige(
      pm25 ~ 1,
      locations = pontos,
      newdata = grid,
      model = modelo_ajustado
    )
    
    return(as.data.frame(krigagem_resultado))
  }
  
  resultado_krig <- interpolar_krigagem(pontos, grid)
  
  # 1.4 Ajustar gradiente baseado no vento
  ajustar_gradiente_vento <- function(grid_df, dir_vento, vel_vento, valor_central) {
    dir_rad <- dir_vento * pi / 180
    
    # Calcular componente na direção do vento
    grid_df$proj_vento <- (grid_df$x * sin(dir_rad) + grid_df$y * cos(dir_rad)) / 1000
    
    # Ajustar concentração: decai a jusante, aumenta a montante
    # Fator de ajuste: 0.8 a 1.2 baseado na posição relativa
    grid_df$fator_vento <- 1.0 + 0.2 * (grid_df$proj_vento / buffer_km)
    
    # Suavizar o ajuste
    grid_df$var1.pred_ajustado <- grid_df$var1.pred * grid_df$fator_vento
    
    # Garantir que a estação mantenha o valor medido
    dist_estacao <- sqrt(grid_df$x^2 + grid_df$y^2)
    idx_estacao <- which.min(dist_estacao)
    grid_df$var1.pred_ajustado[idx_estacao] <- valor_central
    
    # Limites razoáveis
    grid_df$var1.pred_ajustado <- pmax(5, pmin(150, grid_df$var1.pred_ajustado))
    
    return(grid_df)
  }
  
  resultado_final <- ajustar_gradiente_vento(resultado_krig, dir_vento, vel_vento, valor_estacao)
  
  # 1.5 Gerar visualização
  gerar_mapa_buffer <- function(grid_df, pontos_df, buffer_km, dir_vento, vel_vento, valor_estacao) {
    
    # Criar seta para direção do vento
    arrow_length <- buffer_km * 0.3
    dir_rad <- dir_vento * pi / 180
    arrow_x <- arrow_length * sin(dir_rad)
    arrow_y <- arrow_length * cos(dir_rad)
    
    # Mapa principal
    p <- ggplot() +
      # Grade interpolada
      geom_tile(data = grid_df, 
                aes(x = x/1000, y = y/1000, fill = var1.pred_ajustado)) +
      
      # Contornos
      geom_contour(data = grid_df,
                   aes(x = x/1000, y = y/1000, z = var1.pred_ajustado),
                   color = "white", alpha = 0.3, bins = 8) +
      
      # Pontos de amostragem
      geom_point(data = as.data.frame(pontos), 
                 aes(x = x/1000, y = y/1000),
                 color = "black", size = 2, shape = 1) +
      
      # Estação (destaque)
      geom_point(data = data.frame(x = 0, y = 0),
                 aes(x = x, y = y),
                 color = "yellow", fill = "black",
                 size = 6, shape = 21, stroke = 2) +
      
      # Seta do vento
      geom_segment(aes(x = 0, y = 0, 
                       xend = arrow_x, yend = arrow_y),
                   arrow = arrow(length = unit(0.3, "cm")),
                   color = "blue", size = 1.2) +
      annotate("text", x = arrow_x/2, y = arrow_y/2,
               label = "Vento", color = "blue", size = 3.5) +
      
      # Buffer circular
      annotate("path",
               x = buffer_km * cos(seq(0, 2*pi, length.out = 100)),
               y = buffer_km * sin(seq(0, 2*pi, length.out = 100)),
               color = "black", size = 0.8, linetype = "dashed") +
      
      # Escala de cores
      scale_fill_viridis(
        name = "PM2.5\n(μg/m³)",
        option = "plasma",
        limits = c(5, max(grid_df$var1.pred_ajustado) * 1.1)
      ) +
      
      # Formatação
      coord_fixed(ratio = 1) +
      labs(
        title = paste("Estimativa de PM2.5 - Buffer de", buffer_km, "km"),
        subtitle = sprintf("Estação: %.1f μg/m³ | Vento: %.0f° @ %.1f m/s", 
                           valor_estacao, dir_vento, vel_vento),
        x = "Distância Leste-Oeste (km)",
        y = "Distância Norte-Sul (km)",
        caption = "Interpolação por Krigagem + ajuste de gradiente de vento"
      ) +
      theme_minimal() +
      theme(
        plot.title = element_text(hjust = 0.5, face = "bold"),
        legend.position = "right"
      )
    
    return(p)
  }
  
  mapa <- gerar_mapa_buffer(resultado_final, pontos, buffer_km, dir_vento, vel_vento, valor_estacao)
  
  # 1.6 Estatísticas
  cat("\n=== ESTATÍSTICAS DO BUFFER ===\n")
  cat(sprintf("PM2.5 na estação: %.1f μg/m³\n", valor_estacao))
  cat(sprintf("Média no buffer: %.1f μg/m³\n", mean(resultado_final$var1.pred_ajustado)))
  cat(sprintf("Máximo no buffer: %.1f μg/m³\n", max(resultado_final$var1.pred_ajustado)))
  cat(sprintf("Mínimo no buffer: %.1f μg/m³\n", min(resultado_final$var1.pred_ajustado)))
  cat(sprintf("Área > 25 μg/m³: %.1f km²\n", 
              sum(resultado_final$var1.pred_ajustado > 25) * (resolucao_m/1000)^2))
  
  # 1.7 Retornar resultados
  resultados <- list(
    parametros = data.frame(
      valor_estacao = valor_estacao,
      dir_vento = dir_vento,
      vel_vento = vel_vento,
      buffer_km = buffer_km
    ),
    pontos_amostrais = as.data.frame(pontos),
    grade_resultado = resultado_final,
    mapa = mapa,
    estatisticas = list(
      media = mean(resultado_final$var1.pred_ajustado),
      maximo = max(resultado_final$var1.pred_ajustado),
      minimo = min(resultado_final$var1.pred_ajustado),
      area_acima_25 = sum(resultado_final$var1.pred_ajustado > 25) * (resolucao_m/1000)^2,
      area_acima_50 = sum(resultado_final$var1.pred_ajustado > 50) * (resolucao_m/1000)^2
    )
  )
  
  print(mapa)
  return(resultados)
}

# -------------------------------------------------
# 2. FUNÇÃO ALTERNATIVA: Modelo de Decaimento Exponencial
# -------------------------------------------------
# Mais simples, baseado apenas em decaimento com distância e vento
estimar_buffer_decaimento <- function(
    valor_estacao,
    dir_vento,
    vel_vento,
    buffer_km = 5,
    resolucao_m = 200,
    decaimento_base = 0.15  # taxa de decaimento por km
) {
  
  cat("Estimativa por modelo de decaimento exponencial...\n")
  
  # Criar grade
  raio_m <- buffer_km * 1000
  grid <- expand.grid(
    x = seq(-raio_m, raio_m, by = resolucao_m),
    y = seq(-raio_m, raio_m, by = resolucao_m)
  )
  grid$dist_centro <- sqrt(grid$x^2 + grid$y^2) / 1000
  grid <- grid[grid$dist_centro <= buffer_km, ]
  
  # Converter direção do vento
  dir_rad <- dir_vento * pi / 180
  
  # Calcular fator de decaimento baseado na direção
  # 1. Decaimento com distância do centro
  # 2. Efeito do vento: mais concentração a montante, menos a jusante
  
  grid$angulo <- atan2(grid$y, grid$x)
  grid$dif_angulo <- abs((grid$angulo - dir_rad + pi) %% (2*pi) - pi)
  
  # Fator de direção: 1.0 a montante, 0.7 a jusante
  grid$fator_direcao <- 1.2 - 0.4 * (grid$dif_angulo / pi)
  
  # Decaimento com distância (ajustado pelo vento)
  # Vento forte = decaimento mais rápido a jusante
  fator_vento <- 1 / (vel_vento + 1)
  
  grid$pm25_estimado <- valor_estacao * 
    exp(-decaimento_base * grid$dist_centro * grid$fator_direcao * fator_vento)
  
  # Adicionar background mínimo
  grid$pm25_estimado <- pmax(5, grid$pm25_estimado)
  
  # Garantir valor exato na estação
  idx_centro <- which.min(grid$dist_centro)
  grid$pm25_estimado[idx_centro] <- valor_estacao
  
  # Gerar mapa
  p <- ggplot(grid, aes(x = x/1000, y = y/1000)) +
    geom_tile(aes(fill = pm25_estimado)) +
    geom_point(aes(x = 0, y = 0), 
               color = "yellow", fill = "black",
               size = 5, shape = 21, stroke = 2) +
    scale_fill_viridis(name = "PM2.5\n(μg/m³)", option = "plasma") +
    coord_fixed(ratio = 1) +
    labs(
      title = paste("Estimativa de PM2.5 - Buffer", buffer_km, "km"),
      subtitle = sprintf("Estação: %.1f μg/m³ | Modelo: Decaimento Exponencial", valor_estacao),
      x = "Distância (km)", y = "Distância (km)"
    ) +
    theme_minimal()
  
  # Estatísticas
  stats <- list(
    media = mean(grid$pm25_estimado),
    maximo = max(grid$pm25_estimado),
    minimo = min(grid$pm25_estimado),
    area_acima_25 = sum(grid$pm25_estimado > 25) * (resolucao_m/1000)^2
  )
  
  print(p)
  
  return(list(
    grade = grid,
    mapa = p,
    estatisticas = stats
  ))
}

# -------------------------------------------------
# 3. FUNÇÃO PARA ANÁLISE COMPARATIVA
# -------------------------------------------------
analisar_buffer_completo <- function(
    valor_estacao,
    dir_vento,
    vel_vento,
    buffer_km = 5
) {
  
  cat("=========================================\n")
  cat("ANÁLISE COMPLETA DO BUFFER DE", buffer_km, "KM\n")
  cat("=========================================\n")
  
  # Método 1: Krigagem
  cat("\n--- MÉTODO 1: INTERPOLAÇÃO ESPACIAL ---\n")
  resultado_krig <- estimar_buffer_krigagem(
    valor_estacao = valor_estacao,
    dir_vento = dir_vento,
    vel_vento = vel_vento,
    buffer_km = buffer_km,
    resolucao_m = 300
  )
  
  # Método 2: Decaimento
  cat("\n--- MÉTODO 2: DECAIMENTO EXPONENCIAL ---\n")
  resultado_dec <- estimar_buffer_decaimento(
    valor_estacao = valor_estacao,
    dir_vento = dir_vento,
    vel_vento = vel_vento,
    buffer_km = buffer_km,
    resolucao_m = 300
  )
  
  # Comparação
  cat("\n=== COMPARAÇÃO DOS MÉTODOS ===\n")
  cat(sprintf("%-25s %10s %10s\n", "Estatística", "Krigagem", "Decaimento"))
  cat(sprintf("%-25s %10.1f %10.1f\n", "Média (μg/m³)", 
              resultado_krig$estatisticas$media,
              resultado_dec$estatisticas$media))
  cat(sprintf("%-25s %10.1f %10.1f\n", "Máximo (μg/m³)", 
              resultado_krig$estatisticas$maximo,
              resultado_dec$estatisticas$maximo))
  cat(sprintf("%-25s %10.1f %10.1f\n", "Área >25 μg/m³ (km²)", 
              resultado_krig$estatisticas$area_acima_25,
              resultado_dec$estatisticas$area_acima_25))
  
  # Combinar gráficos
  library(patchwork)
  plot_combinado <- resultado_krig$mapa + resultado_dec$mapa +
    plot_annotation(title = paste("Comparação de Métodos - PM2.5:", valor_estacao, "μg/m³"))
  
  print(plot_combinado)
  
  return(list(
    krigagem = resultado_krig,
    decaimento = resultado_dec,
    comparacao = plot_combinado
  ))
}

# -------------------------------------------------
# 4. EXEMPLOS PRÁTICOS
# -------------------------------------------------

# Exemplo 1: Caso moderado
cat("\n\n=== EXEMPLO 1: CASO MODERADO ===\n")
exemplo1 <- estimar_buffer_krigagem(
  valor_estacao = 5,
  dir_vento = 315,  # Vento NW
  vel_vento = 3.5,
  buffer_km = 5
)

# Exemplo 2: Alta poluição
cat("\n\n=== EXEMPLO 2: ALTA POLUIÇÃO ===\n")
exemplo2 <- estimar_buffer_krigagem(
  valor_estacao = 85,
  dir_vento = 180,  # Vento Sul
  vel_vento = 10,  # Vento fraco
  buffer_km = 2.5
)

# Exemplo 3: Análise comparativa
cat("\n\n=== EXEMPLO 3: ANÁLISE COMPARATIVA ===\n")
analise <- analisar_buffer_completo(
  valor_estacao = 40,
  dir_vento = 0,  
  vel_vento = 10,
  buffer_km = 5
)

# -------------------------------------------------
# 5. FUNÇÃO PARA PROCESSAR DADOS REAIS
# -------------------------------------------------
processar_dados_estacao <- function(
    dados,          # DataFrame com colunas: data_hora, pm25, dir_vento, vel_vento
    buffer_km = 5,
    metodo = "krigagem"  # "krigagem" ou "decaimento"
) {
  
  cat("Processando", nrow(dados), "registros da estação...\n")
  
  resultados <- list()
  
  for(i in 1:nrow(dados)) {
    cat(sprintf("\nRegistro %d/%d: %s\n", i, nrow(dados), dados$data_hora[i]))
    
    if(metodo == "krigagem") {
      res <- estimar_buffer_krigagem(
        valor_estacao = dados$pm25[i],
        dir_vento = dados$dir_vento[i],
        vel_vento = dados$vel_vento[i],
        buffer_km = buffer_km,
        resolucao_m = 250
      )
    } else {
      res <- estimar_buffer_decaimento(
        valor_estacao = dados$pm25[i],
        dir_vento = dados$dir_vento[i],
        vel_vento = dados$vel_vento[i],
        buffer_km = buffer_km,
        resolucao_m = 250
      )
    }
    
    resultados[[i]] <- list(
      data_hora = dados$data_hora[i],
      resultado = res
    )
  }
  
  # Sumário
  cat("\n=== SUMÁRIO DOS RESULTADOS ===\n")
  medias <- sapply(resultados, function(x) x$resultado$estatisticas$media)
  maximos <- sapply(resultados, function(x) x$resultado$estatisticas$maximo)
  
  cat(sprintf("Média das médias: %.1f μg/m³\n", mean(medias)))
  cat(sprintf("Média dos máximos: %.1f μg/m³\n", mean(maximos)))
  cat(sprintf("Variação média: ±%.1f%%\n", 
              sd(medias)/mean(medias)*100))
  
  return(resultados)
}

# -------------------------------------------------
# 6. FUNÇÃO PARA EXPORTAR RESULTADOS
# -------------------------------------------------
exportar_buffer_estimado <- function(resultado, prefixo = "buffer_pm25") {
  
  # Dados da grade
  write.csv(
    resultado$grade_resultado,
    file = paste0(prefixo, "_grade.csv"),
    row.names = FALSE
  )
  
  # Estatísticas
  stats_df <- data.frame(
    estatistica = names(resultado$estatisticas),
    valor = unlist(resultado$estatisticas)
  )
  write.csv(
    stats_df,
    file = paste0(prefixo, "_estatisticas.csv"),
    row.names = FALSE
  )
  
  # Mapa
  ggsave(
    filename = paste0(prefixo, "_mapa.png"),
    plot = resultado$mapa,
    width = 8, height = 7, dpi = 300
  )
  
  # Pontos de amostragem
  write.csv(
    resultado$pontos_amostrais,
    file = paste0(prefixo, "_pontos.csv"),
    row.names = FALSE
  )
  
  cat("Arquivos exportados:\n")
  cat(paste0("- ", prefixo, "_grade.csv\n"))
  cat(paste0("- ", prefixo, "_estatisticas.csv\n"))
  cat(paste0("- ", prefixo, "_mapa.png\n"))
  cat(paste0("- ", prefixo, "_pontos.csv\n"))
}

# -------------------------------------------------
# 7. USO SIMPLIFICADO (RECOMENDADO PARA INÍCIO)
# -------------------------------------------------

# Função única para uso rápido
estimar_pm25_buffer <- function(pm25_estacao, dir_vento, vel_vento) {
  
  cat("=== ESTIMATIVA RÁPIDA DE PM2.5 NO BUFFER ===\n\n")
  
  # Usar método de decaimento (mais rápido e estável)
  resultado <- estimar_buffer_decaimento(
    valor_estacao = pm25_estacao,
    dir_vento = dir_vento,
    vel_vento = vel_vento,
    buffer_km = 5,
    resolucao_m = 200
  )
  
  # Relatório simples
  cat("\n=== RELATÓRIO ===\n")
  cat(sprintf("Valor na estação: %.1f μg/m³\n", pm25_estacao))
  cat(sprintf("Média no buffer (5km): %.1f μg/m³\n", resultado$estatisticas$media))
  cat(sprintf("Variação no buffer: %.1f a %.1f μg/m³\n", 
              resultado$estatisticas$minimo, 
              resultado$estatisticas$maximo))
  cat(sprintf("Área com >25 μg/m³: %.1f km² (%.0f%% do buffer)\n",
              resultado$estatisticas$area_acima_25,
              resultado$estatisticas$area_acima_25 / (pi * 5^2) * 100))
  
  # Sugestão qualitativa
  if(resultado$estatisticas$area_acima_25 > 10) {
    cat("\n⚠️  ALERTA: Grande área do buffer apresenta alta concentração!\n")
  } else if(resultado$estatisticas$area_acima_25 > 5) {
    cat("\n⚠️  ATENÇÃO: Área significativa com concentração elevada.\n")
  } else {
    cat("\n✅  Situação: Concentração mais localizada na estação.\n")
  }
  
  # Exportar automaticamente
  nome_arquivo <- sprintf("pm25_%.0f_dir%.0f", pm25_estacao, dir_vento)
  exportar_buffer_estimado(list(
    grade_resultado = resultado$grade,
    estatisticas = resultado$estatisticas,
    mapa = resultado$mapa,
    pontos_amostrais = data.frame(x=0, y=0, pm25=pm25_estacao)
  ), nome_arquivo)
  
  return(resultado)
}

# -------------------------------------------------
# EXECUTAR COM SEUS DADOS
# -------------------------------------------------

# Substitua com SUAS medições:
meu_resultado <- estimar_pm25_buffer(
  pm25_estacao = 65,     # SUA medição de PM2.5
  dir_vento = 270,       # SUA direção do vento
  vel_vento = 2.8        # SUA velocidade do vento
)

# Para ver os dados:
# View(meu_resultado$grade)
# print(meu_resultado$estatisticas)